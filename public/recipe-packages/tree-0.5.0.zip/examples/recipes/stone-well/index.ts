import { jointGroup } from '../../../src/catalog/semantics.ts';
import { Box3, Group, Mesh, MeshStandardMaterial, Vector3, Shape, ExtrudeGeometry, LatheGeometry, Vector2, TorusGeometry, type BufferGeometry } from 'three';
import { profileSolid, profiledBeam, taperedSweep } from '../../../src/engine/geometry.ts';
import { parseControls, parameterState, plainRecord, ParameterError } from '../../../src/engine/parameters.ts';
import type { Control, Design, Descriptor } from '../../../src/engine/parameters.ts';
import type { AssetBuild } from '../../../src/catalog/types.ts';
import type { Recipe, RecipeCase } from '../../../src/recipes/types.ts';

const colors = {stone:'#898880',coping:'#b2ac96',timber:'#62432e',roof:'#a77342',iron:'#343b3b',rope:'#bca879'};
const controls:Control[] = [
  {key:'diameter',label:'Outside diameter',kind:'range',group:'shape',unit:'m',min:1.8,max:3.2,step:0.05,default:2.2,hint:'Outside masonry diameter. Shaft stays open with 25 cm walls.',affects:['geometry'],targets:['stone','coping','post','windlass','roof-board']},
  {key:'wallHeight',label:'Wall height',kind:'range',group:'shape',unit:'m',min:0.65,max:1.4,step:0.05,default:0.95,hint:'Ground to coping top. Timber and mechanism follow the wall.',affects:['geometry','topology'],targets:['stone','coping','post','windlass','bucket-shell']},
  {key:'roofSize',label:'Roof size',kind:'range',group:'shape',unit:'ratio',ratioBasis:'width',min:1.15,max:1.6,step:0.05,default:1.35,hint:'Roof width as a multiple of well diameter. Depth is 85 percent of width.',affects:['geometry','topology'],targets:['roof-board','rafter','ridge']},
  {key:'roof',label:'Timber roof',kind:'toggle',group:'construction',unit:'none',default:true,hint:'Roof boards, rafters and braces; posts remain with an open top.',affects:['topology'],targets:['roof-board','rafter','ridge','fascia','tie','brace','post']},
  {key:'bucket',label:'Suspended bucket',kind:'toggle',group:'construction',unit:'none',default:true,hint:'Bucket, handle and hanging rope. Requires the windlass.',affects:['topology'],targets:['bucket','hanging-rope']},
  {key:'windlass',label:'Windlass mechanism',kind:'toggle',group:'construction',unit:'none',default:true,hint:'Axle, bearings, crank and rope spool. Remove the bucket before disabling.',affects:['topology'],targets:['windlass','axle-bearing','spool-flange','crank','rope-coil']},
  {key:'bucketDrop',label:'Bucket drop',kind:'range',group:'construction',unit:'m',min:0,max:0.6,step:0.05,default:0,hint:'Lowers the bucket from its default height and lengthens the hanging rope.',affects:['geometry'],targets:['bucket','hanging-rope']},
  ...Object.entries(colors).map(([role,color]):Control=>({key:'color.'+role,label:role,kind:'color',group:'colors',unit:'color',default:color,role,hint:'Color of '+role+' parts.',affects:['material'],targets:[role]})),
];
function relationships(p:Record<string,unknown>) {
  return p.bucket&&!p.windlass?[{code:'relationship',keys:['bucket','windlass'],message:'Suspended bucket requires the windlass. Remove bucket or enable windlass.'}]:[];
}
function parse(input:unknown) {
  const p=parseControls(controls,input),issues=relationships(p);
  if(issues.length)throw new ParameterError(issues);
  return p;
}
function save(input:unknown):Design {const requested={...plainRecord(input)};return {formatVersion:1,family:'stone-well',familyVersion:'1.0.0',requested,applied:parse(requested)};}
function load(input:unknown):Design {
  const v=plainRecord(input);
  if(Reflect.ownKeys(v).some(k=>typeof k!=='string'||!['formatVersion','family','familyVersion','requested','applied'].includes(k)))throw Error('Unknown stone well design field');
  if(v.formatVersion!==1||v.family!=='stone-well'||v.familyVersion!=='1.0.0')throw Error('Unsupported stone well design version');
  const d=save(v.requested),a=plainRecord(v.applied);
  if(Reflect.ownKeys(a).length!==Object.keys(d.applied).length||Object.entries(d.applied).some(([k,x])=>a[k]!==x))throw Error('Stone well applied parameters mismatch');
  return d;
}
function wedge(inner:number,outer:number,start:number,end:number,height:number,bevel:number) {
  const s=new Shape();
  s.moveTo(outer*Math.cos(start),outer*Math.sin(start));
  for(let i=1;i<=3;i++){const a=start+(end-start)*i/3;s.lineTo(outer*Math.cos(a),outer*Math.sin(a));}
  for(let i=3;i>=0;i--){const a=start+(end-start)*i/3;s.lineTo(inner*Math.cos(a),inner*Math.sin(a));}
  s.closePath();
  const g=new ExtrudeGeometry(s,{depth:height-2*bevel,steps:1,bevelEnabled:true,bevelSegments:1,bevelSize:bevel,bevelThickness:bevel,curveSegments:1});
  g.clearGroups();g.rotateX(-Math.PI/2);g.translate(0,bevel,0);return g;
}
function build(input:unknown):AssetBuild {
  const config=save(input),p=config.applied,d=Number(p.diameter),h=Number(p.wallHeight),size=Number(p.roofSize),r=d/2;
  const root=new Group();root.name='stone-well';
  const materials=Object.fromEntries(Object.keys(colors).map(role=>[role,new MeshStandardMaterial({name:role,color:String(p['color.'+role]),roughness:role==='iron'?0.65:0.92,metalness:role==='iron'?0.45:0,flatShading:true})]));
  const anchors={ground:[0,0,0],shaft:[0,h,0],bucket:[0,h+0.15-Number(p.bucketDrop),0.125]};
  root.userData={configuration:config,units:'meters',up:'+Y',forward:'+Z',origin:'ground-center',anchors};
  function add(name:string,role:string,g:BufferGeometry,pos:[number,number,number]=[0,0,0]) {g.normalizeNormals();const m=new Mesh(g,materials[role]);m.name=name;m.userData={materialRole:role};m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;root.add(m);return m;}
  function beam(name:string,a:[number,number,number],b:[number,number,number],w:number,depth=w,role='timber') {return add(name,role,profiledBeam(a,b,w,depth,Math.min(w,depth)*0.08));}
  function rod(name:string,a:[number,number,number],b:[number,number,number],radius:number,role:string,sides=10) {return add(name,role,taperedSweep([{center:a,radius},{center:b,radius}],sides));}
  const courses=Math.max(3,Math.round(h/0.24)),cap=0.16,course=(h-cap)/courses,segments=14;
  const mortarProfile=[[r-0.235,0],[r-0.03,0],[r-0.03,h-cap],[r-0.235,h-cap],[r-0.235,0]].map(([x,y])=>new Vector2(x!,y!));
  add('stone-mortar','stone',new LatheGeometry(mortarProfile,42));
  for(let row=0;row<courses;row++)for(let i=0;i<segments;i++){
    const a=(i+(row%2)*0.5)*2*Math.PI/segments,gap=0.014/r;
    add('stone-'+row+'-'+i,'stone',wedge(r-0.25+0.012,r-0.012,a+gap,a+2*Math.PI/segments-gap,course-0.012,0.012),[0,row*course,0]);
  }
  for(let i=0;i<segments;i++){const a=i*2*Math.PI/segments;add('coping-'+i,'coping',wedge(r-0.27+0.012,r-0.012,a+0.008/r,a+2*Math.PI/segments-0.008/r,cap,0.012),[0,h-cap,0]);}
  const px=r-0.13,eave=h+1.4,width=d*size,depth=width*0.85,half=depth/2,rise=half*0.58,ridge=eave+rise;
  for(const side of [-1,1]) {
    beam('post-'+side,[side*px,h-0.08,0],[side*px,p.roof?ridge-0.035:h+1.25,0],0.18);
    if(p.roof) {
    beam('tie-'+side,[side*px,eave,-half],[side*px,eave,half],0.12);
    for(const end of [-1,1]){
      beam('rafter-'+side+'-'+end,[side*px,eave,end*half],[side*px,ridge,0],0.12);
      beam('brace-'+side+'-'+end,[side*px,eave-0.48,0],[side*px,eave,end*0.48],0.09);
    }
    }
    if(p.windlass)rod('axle-bearing-'+side,[side*(px-0.11),h+0.95,0],[side*(px+0.11),h+0.95,0],0.155,'iron');
  }
  if(p.roof) {
  beam('ridge',[-width/2,ridge,0],[width/2,ridge,0],0.12);
  const boards=Math.ceil(width/0.24),boardWidth=width/boards;
  for(const side of [-1,1])for(let i=0;i<boards;i++){
    const x=-width/2+boardWidth*(i+0.5),length=Math.hypot(half,rise)+0.07;
    const g=profileSolid([{y:-0.026,width:boardWidth-0.006,depth:length,chamfer:0.006},{y:0.026,width:boardWidth-0.006,depth:length,chamfer:0.006}]);
    const m=add('roof-board-'+side+'-'+i,'roof',g,[x,eave+rise/2+0.07,side*half/2]);m.rotation.x=side*Math.atan2(rise,half);
  }
  for(const side of [-1,1])beam('fascia-'+side,[-width/2,eave+0.015,side*half],[width/2,eave+0.015,side*half],0.09);
  }
  const axle=h+0.95;
  if(p.windlass) {
  rod('windlass',[-px-0.24,axle,0],[px+0.24,axle,0],0.105,'timber',12);
  for(const side of [-1,1])rod('spool-flange-'+side,[side*0.18-0.025,axle,0],[side*0.18+0.025,axle,0],0.15,'timber',12);
  for(let i=0;i<11;i++) {const g=new TorusGeometry(0.118,0.012,4,16);g.rotateY(Math.PI/2);add('rope-coil-'+i,'rope',g,[-0.14+i*0.028,axle,0]);}
  rod('crank-arm',[px+0.24,axle,0],[px+0.24,axle-0.27,0],0.035,'iron',8);
  rod('crank-grip',[px+0.22,axle-0.27,0],[px+0.43,axle-0.27,0],0.052,'timber',8);
  }
  if(p.bucket) {
  const bottom=h+0.15-Number(p.bucketDrop),top=bottom+0.32,zc=0.125;
  const profile=[[0.135,0],[0.185,0.32],[0.16,0.32],[0.113,0.025],[0.135,0]].map(([x,y])=>new Vector2(x!,y!));
  add('bucket-shell','roof',new LatheGeometry(profile,10),[0,bottom,zc]);
  rod('bucket-bottom',[0,bottom+0.003,zc],[0,bottom+0.026,zc],0.133,'roof',10);
  for(const level of [0.06,0.26]){const g=new TorusGeometry(0.135+level/0.32*0.05,0.012,4,10);g.rotateZ(Math.PI/2);g.rotateX(Math.PI/2);add('bucket-band-'+level,'iron',g,[0,bottom+level,zc]);}
  const handle=Array.from({length:9},(_,i)=>{const a=i*Math.PI/8;return {center:[0.18*Math.cos(a),top+0.18*Math.sin(a),zc] as [number,number,number],radius:0.012};});
  add('bucket-handle','iron',taperedSweep(handle,6));
  rod('hanging-rope',[0,top+0.18,zc],[0,axle,zc],0.012,'rope',6);
  }
  const joints=[];
  if(p.windlass){
   const pivot:[number,number,number]=[0,axle,0];
   jointGroup(root,'windlass-pivot',pivot,root.children.filter(item=>item.name==='windlass'||item.name.startsWith('spool-flange-')||item.name.startsWith('crank-')));
   joints.push({id:'windlass-pivot',node:'windlass-pivot',kind:'revolute' as const,pivot,axis:[1,0,0] as [number,number,number],angleUnit:'degrees' as const,limits:[-180,180] as [number,number],angle:0});
  }
  root.updateMatrixWorld(true);const bounds=new Box3().setFromObject(root,true);
  return {root,config,materials,anchors,joints,bounds,dimensions:bounds.getSize(new Vector3())};
}
const presets:Descriptor['presets']=[
  {id:'village',name:'Village well',description:'Warm timber above a modest stone shaft.',parameters:{}},
  {id:'courtyard',name:'Courtyard well',description:'Compact open-top well with a lowered suspended bucket.',parameters:{diameter:1.8,wallHeight:0.7,roofSize:1.2,roof:false,bucketDrop:0.35}},
  {id:'market',name:'Market well',description:'Broad sheltered shaft with its bucket removed.',parameters:{diameter:3,wallHeight:1.25,roofSize:1.5,bucket:false}},
];
const boundaries:RecipeCase[]=controls.flatMap(c=>c.kind==='range'?[{id:c.key.toLowerCase()+'-min',name:c.label+' minimum',parameters:{[c.key]:c.min}},{id:c.key.toLowerCase()+'-max',name:c.label+' maximum',parameters:{[c.key]:c.max}}]:[]);
export const stoneWellRecipe:Recipe={
  descriptor:{id:'stone-well',version:'1.0.0',title:'Stone well',description:'Open masonry shaft, timber shelter, windlass and suspended bucket.',controls,defaults:parse({}),presets,palettes:[{id:'warm',label:'Weathered stone and oak',colors:Object.values(colors),parameters:Object.fromEntries(Object.entries(colors).map(([role,color])=>['color.'+role,color]))}],save,state:input=>{
    const state=parameterState(controls,input,relationships);
    try {const p=parseControls(controls,input);state.controls.bucketDrop!.enabled=Boolean(p.bucket&&p.windlass);state.controls.roofSize!.enabled=Boolean(p.roof);} catch {}
    return state;
  }},
  build,load,validationCases:[...presets,...boundaries,{id:'bare-shaft',name:'Open shaft without mechanism',parameters:{roof:false,bucket:false,windlass:false}},{id:'low-bucket',name:'Lowest bucket at minimum wall height',parameters:{diameter:1.8,wallHeight:0.65,bucketDrop:0.6}}],integrationCases:presets,
  constraints:['Static prop in meters. Diameter 1.8–3.2 m; wall 0.65–1.4 m; roof multiplier 1.15–1.6. Open shaft without floor or underground lining. Roof removal retains posts. Bucket needs the windlass; bucket drop lengthens the rope. No collision or animation.'],
  presentation:{category:'Props',order:100,kitIds:[],thumbnails:Object.fromEntries(presets.map(p=>[p.id,'stone-well-'+p.id+'.png']))},source:{entry:'examples/recipes/stone-well/index.ts',exportName:'stoneWellRecipe'},
};
