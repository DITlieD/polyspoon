import { Box3, BufferGeometry, Group, Mesh, MeshStandardMaterial, Vector3 } from 'three';
import { facetedLoft, taperedSweep } from '../../../src/engine/geometry.ts';
import { parseControls, parameterState, plainRecord } from '../../../src/engine/parameters.ts';
import type { Control, Design, Descriptor } from '../../../src/engine/parameters.ts';
import type { AssetBuild } from '../../../src/catalog/types.ts';
import type { Recipe } from '../../../src/recipes/types.ts';

const controls: Control[] = [
  {key:'height',label:'Height',kind:'range',group:'shape',unit:'m',min:2,max:12,step:0.1,default:6,hint:'Ground to highest needle.',affects:['geometry'],targets:['trunk','branch','foliage']},
  {key:'crownSpread',label:'Crown spread',kind:'range',group:'shape',unit:'m',min:1,max:7,step:0.1,default:3.8,hint:'Larger horizontal bounding-box dimension.',affects:['geometry'],targets:['trunk','branch','foliage']},
  {key:'seed',label:'Variation seed',kind:'integer',group:'construction',unit:'seed',min:0,max:65535,step:1,default:317,hint:'Repeatable trunk bends, branch spacing and foliage variation.',affects:['geometry'],targets:['trunk','branch','foliage']},
  {key:'tierCount',label:'Crown tiers',kind:'integer',group:'construction',unit:'count',min:5,max:10,step:1,default:8,hint:'Redistributes five to ten connected branch tiers through the same crown envelope, with fewer branches and smaller lobes toward the leader.',affects:['topology','geometry'],targets:['branch','foliage']},
  ...Object.entries({bark:'#70523a',needles:'#365c43',tips:'#55754c',shade:'#284c3c'}).map(([role,color]):Control=>({key:'color.'+role,label:role,kind:'color',group:'colors',unit:'color',default:color,role,hint:'Opaque faceted '+role+' material.',affects:['material'],targets:[role]})),
];
const parse=(input:unknown)=>parseControls(controls,plainRecord(input));
function save(input:unknown):Design {
  const requested={...plainRecord(input)};
  return {formatVersion:1,family:'conifer',familyVersion:'1.0.0',requested,applied:parse(requested)};
}
function load(input:unknown):Design {
  const v=plainRecord(input);
  if(Reflect.ownKeys(v).some(k=>typeof k!=='string'||!['formatVersion','family','familyVersion','requested','applied'].includes(k)))throw new Error('Unknown conifer design field');
  if(v.formatVersion!==1||v.family!=='conifer'||v.familyVersion!=='1.0.0')throw new Error('Unsupported conifer design');
  const d=save(v.requested),a=plainRecord(v.applied);
  if(Object.keys(a).length!==Object.keys(d.applied).length||Object.entries(d.applied).some(([k,x])=>a[k]!==x))throw new Error('Conifer applied parameters mismatch');
  return d;
}
function build(input:unknown):AssetBuild {
  const config=save(input),p=config.applied;
  let state=Number(p.seed)>>>0;
  const random=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
  const root=new Group();root.name='conifer';
  const materials=Object.fromEntries(['bark','needles','tips','shade'].map(role=>[role,new MeshStandardMaterial({name:role,color:String(p['color.'+role]),roughness:0.95,flatShading:true})]));
  function add(name:string,role:string,g:BufferGeometry,connectedTo?:string) {
    const m=new Mesh(g,materials[role]);m.name=name;m.userData={materialRole:role,...(connectedTo?{connectedTo}:{})};m.castShadow=true;m.receiveShadow=true;root.add(m);return m;
  }
  const spine=Array.from({length:8},(_,i)=>new Vector3(i===0?0:(random()-.5)*.12,i*6/7,i===0?0:(random()-.5)*.12));
  spine[7]!.set(spine[6]!.x,5.48,spine[6]!.z);
  const centerAt=(y:number)=>{
    const index=Math.min(6,Math.floor(y/6*7));
    return spine[index]!.clone().lerp(spine[index+1]!,y/6*7-index);
  };
  add('trunk','bark',taperedSweep(spine.map((v,i)=>({center:v.toArray(),radius:.14*(1-i/8)**1.3+.008})),7));
  function tuft(name:string,center:Vector3,length:number,width:number,height:number,angle:number,role:string,parent:string) {
    const outline=Array.from({length:7},(_,i):[number,number]=>{
      const a=i*2*Math.PI/7,r=.88+random()*.24;
      return [Math.cos(a)*length*r,Math.sin(a)*width*r];
    });
    const g=facetedLoft([
      {center:[0,-height*.45,0],outline:outline.map(([x,z])=>[x*.55,z*.55])},
      {center:[0,0,0],outline},
      {center:[-length*.12,height*.35,width*.06],outline:outline.map(([x,z])=>[x*.72,z*.72])},
      {center:[-length*.20,height*.6,0],outline:outline.map(([x,z])=>[x*.30,z*.30])},
    ]);
    g.rotateZ(-.23);g.rotateY(-angle);g.translate(center.x,center.y,center.z);add(name,role,g,parent);
  }
  for(let tier=0;tier<Number(p.tierCount);tier++){
    const levelIndex=tier*7/(Number(p.tierCount)-1);
    const y=1.35+levelIndex*.59;
    const n=levelIndex<3?5:4,phase=random()*Math.PI*2;
    for(let j=0;j<n;j++){
      const angle=phase+j*Math.PI*2/n+(random()-.5)*.38;
      const level=y+(random()-.5)*.25;
      const start=centerAt(level),length=(1.8-levelIndex*.235)*(.79+random()*.36);
      const dir=new Vector3(Math.cos(angle),0,Math.sin(angle));
      const elbow=start.clone().addScaledVector(dir,length*.54);elbow.y-=.10+random()*.14;
      const tip=start.clone().addScaledVector(dir,length);tip.y+=(.10+random()*.18)*(1-levelIndex*.11);
      const branchName='branch-'+tier+'-'+j;
      add(branchName,'bark',taperedSweep([{center:start.toArray(),radius:.052*(1-levelIndex*.09)},{center:elbow.toArray(),radius:.032*(1-levelIndex*.09)},{center:tip.toArray(),radius:.008}],5),'trunk');
      for(let lobe=0;lobe<2;lobe++){
        const t=.55+lobe*.35;
        const c=t<.54?start.clone().lerp(elbow,t/.54):elbow.clone().lerp(tip,(t-.54)/.46);
        const size=(1-levelIndex*.118)*(1-lobe*.18);
        tuft('foliage-'+tier+'-'+j+'-'+lobe,c,.74*size*(.85+random()*.3),.65*size*(.8+random()*.4),.62*size*(.8+random()*.4),angle,['shade','needles','tips'][(j+lobe+tier)%3]!,branchName);
      }
    }
  }

  for(let i=0;i<3;i++){
    const c=spine[7]!.clone();c.y=5.28+i*.10;
    tuft('foliage-leader-'+i,c,.20-i*.055,.17-i*.045,.23-i*.035,i*2.4,'needles','trunk');
  }
  root.updateMatrixWorld(true);
  const raw=new Box3().setFromObject(root,true),size=raw.getSize(new Vector3());
  const sx=Number(p.crownSpread)/Math.max(size.x,size.z),sy=Number(p.height)/size.y;
  root.traverse(o=>{if(o instanceof Mesh){o.geometry.translate(0,-raw.min.y,0);o.geometry.scale(sx,sy,sx);}});
  const anchors={ground:[0,0,0],tip:[spine[7]!.x*sx,Number(p.height),spine[7]!.z*sx]};
  root.userData={configuration:config,units:'meters',up:'+Y',forward:'+Z',origin:'ground-center',anchors};
  root.updateMatrixWorld(true);
  const bounds=new Box3().setFromObject(root,true);
  return {root,config,materials,anchors,bounds,dimensions:bounds.getSize(new Vector3())};
}
const presets:Descriptor['presets']=[
  {id:'woodland',name:'Woodland pine',description:'Uneven open crown with exposed branch joints.',parameters:{}},
  {id:'slender',name:'Slender pine',description:'Tall narrow silhouette with ten close-set tiers.',parameters:{height:9,crownSpread:3,seed:901,tierCount:10}},
  {id:'windswept',name:'Broad pine',description:'Short broad crown with five open tiers.',parameters:{height:4.5,crownSpread:4.7,seed:42,tierCount:5}},
];
export const coniferRecipe:Recipe={
  descriptor:{id:'conifer',version:'1.0.0',title:'Wild pine',description:'Faceted pine with irregular branch tiers and visible connected woody structure.',controls,defaults:parse({}),presets,palettes:[{id:'forest',label:'Forest',colors:['#70523a','#365c43','#55754c','#284c3c'],parameters:{'color.bark':'#70523a','color.needles':'#365c43','color.tips':'#55754c','color.shade':'#284c3c'}}],save,state:input=>parameterState(controls,input)},
  build,load,
  validationCases:[...presets,...controls.flatMap(c=>c.kind==='range'||c.kind==='integer'?[{id:c.key.toLowerCase()+'-min',name:c.label+' minimum',parameters:{[c.key]:c.min}},{id:c.key.toLowerCase()+'-max',name:c.label+' maximum',parameters:{[c.key]:c.max}}]:[]),{id:'short-wide',name:'Short wide boundary',parameters:{height:2,crownSpread:7,seed:0}},{id:'tall-narrow',name:'Tall narrow boundary',parameters:{height:12,crownSpread:1,seed:65535}}],
  integrationCases:[{id:'default',name:'Default pine',parameters:{}},{id:'slender',name:'Slender pine',parameters:presets[1]!.parameters}],
  constraints:['Height is ground to highest geometry; crown spread is max X/Z span. Five to ten tiers share the original crown envelope and taper; eight tiers retain the default construction. Extreme aspect ratios are supported but stylized. Branch meshes intersect the trunk and foliage; they are not welded. No wind, collision or LOD.'],
  presentation:{category:'Nature',order:110,kitIds:[],thumbnails:Object.fromEntries(presets.map(p=>[p.id,'conifer-'+p.id+'.png']))},
  source:{entry:'examples/recipes/conifer/index.ts',exportName:'coniferRecipe'},
};
