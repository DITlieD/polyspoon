import { jointGroup } from '../../../src/catalog/semantics.ts';
import { Box3, Group, Mesh, MeshStandardMaterial, Vector3, Shape, ExtrudeGeometry, BufferGeometry } from 'three';
import { profileSolid, profiledBeam } from '../../../src/engine/geometry.ts';
import { parseControls, parameterState, plainRecord } from '../../../src/engine/parameters.ts';
import type { Control, Design, Descriptor, Parameters } from '../../../src/engine/parameters.ts';
import type { AssetBuild } from '../../../src/catalog/types.ts';
import type { Recipe, RecipeCase } from '../../../src/recipes/types.ts';

const palette = { oak: { wood:'#a86b37', frame:'#343a3e', brass:'#c79535' } };
const ranges = [
  ['width','Width',0.7,1.8,1.2],['depth','Depth',0.45,1,0.7],
  ['bodyHeight','Body height',0.35,0.8,0.58],['lidRise','Lid rise',0.15,0.4,0.28],
  ['bandInset','Band inset',0.15,0.3,0.2],
] as const;
const dimensionControls:Control[]=ranges.map(([key,label,min,max,value]):Control=>({key,label,kind:'range',group:'shape',unit:key==='bandInset'?'none':'m',min,max,step:0.01,default:value,hint:key==='bandInset'?'Fraction of width from each end.':'Outside dimension in meters.',affects:['geometry'],targets:['body','lid','band']}));
const controls: Control[] = [
  ...dimensionControls.slice(0,4),
  {key:'lidAngle',inputUnit:'degrees',label:'Lid opening',kind:'range',group:'construction',unit:'none',min:0,max:110,step:5,default:0,hint:'Static opening in degrees around the rear hinge. Bands and latch follow the lid.',affects:['geometry'],targets:['lid','band-lid','latch','keyhole']},
  {key:'boardCount',label:'Body courses',kind:'integer',group:'construction',unit:'count',min:2,max:6,step:1,default:4,hint:'Body courses preserve the outside height and hollow interior.',affects:['topology'],targets:['body-plank','end-plank']},
  ...dimensionControls.slice(4),
  {key:'latch',label:'Latch',kind:'toggle',group:'construction',unit:'none',default:true,hint:'Adds a front brass latch.',affects:['topology'],targets:['latch']},
  ...Object.entries(palette.oak).map(([role,color]):Control=>({key:'color.'+role,label:role,kind:'color',group:'colors',unit:'color',default:color,role,hint:'Material color.',affects:['material'],targets:[role]})),
];

function parse(input: unknown): Parameters {
  const value = plainRecord(input);
  const checked = parseControls(controls, value);
  const colors = palette.oak;
  for (const role of ['wood','frame','brass'] as const) if (!Object.hasOwn(value, 'color.' + role)) checked['color.' + role] = colors[role];
  return checked;
}

function save(input: unknown): Design {
  const requested = { ...plainRecord(input) };
  return { formatVersion:1, family:'treasure-chest', familyVersion:'1.0.0', requested, applied:parse(requested) };
}

function load(input: unknown): Design {
  const value = plainRecord(input);
  if (Reflect.ownKeys(value).some(key => typeof key !== 'string' || !['formatVersion','family','familyVersion','requested','applied'].includes(key))) throw new Error('Unknown treasure-chest design field');
  if (value.formatVersion !== 1 || value.family !== 'treasure-chest' || value.familyVersion !== '1.0.0') throw new Error('Unsupported treasure-chest design version');
  const design = save(value.requested);
  const applied = plainRecord(value.applied);
  if (Reflect.ownKeys(applied).length !== Object.keys(design.applied).length || Object.entries(design.applied).some(([key, item]) => applied[key] !== item)) throw new Error('Chest applied parameters do not match requested values');
  return design;
}

function build(input: unknown): AssetBuild {
  const config=save(input),p=config.applied;
  const w=Number(p.width),d=Number(p.depth),h=Number(p.bodyHeight),r=Number(p.lidRise);
  const root=new Group();root.name='treasure-chest';
  const materials=Object.fromEntries(['wood','frame','brass'].map(role=>[role,new MeshStandardMaterial({name:role,color:String(p['color.'+role]),roughness:role==='wood'?0.9:0.55,metalness:role==='wood'?0:0.65,flatShading:true})]));
  const anchors={ground:[0,0,0],lid:[0,h,0]};
  root.userData={configuration:config,units:'meters',up:'+Y',forward:'+Z',origin:'ground-center',anchors};
  function mesh(name:string,role:string,geometry:BufferGeometry,position:[number,number,number]=[0,0,0]) {
    const item=new Mesh(geometry,materials[role]);item.name=name;item.userData={materialRole:role};item.position.set(...position);item.castShadow=true;item.receiveShadow=true;root.add(item);return item;
  }
  function box(name:string,role:string,size:[number,number,number],position:[number,number,number]) {
    const [width,height,depth]=size;
    return mesh(name,role,profileSolid([{y:-height/2,width,depth,chamfer:0.002},{y:height/2,width,depth,chamfer:0.002}]),position);
  }
  const floor=0.05;
  box('base','wood',[w,0.05,d],[0,floor+0.025,0]);
  for(const x of [-1,1])for(const z of [-1,1])box('foot-'+x+'-'+z,'frame',[0.08,floor,0.08],[x*(w/2-0.07),floor/2,z*(d/2-0.07)]);
  for(let i=0;i<Number(p.boardCount);i++) {
    const board=(h-floor)/Number(p.boardCount);
    for(const z of [-1,1])box('body-plank-'+z+'-'+i,'wood',[w,board-0.003,0.035],[0,floor+board*(i+0.5),z*(d/2-0.0175)]);
    for(const x of [-1,1])box('end-plank-'+x+'-'+i,'wood',[0.035,board-0.003,d-0.07],[x*(w/2-0.0175),floor+board*(i+0.5),0]);
  }
  const curve=Array.from({length:7},(_,i)=>({z:-d/2+d*i/6,y:h+0.012+r*Math.sin(Math.PI*i/6)}));
  const shape=new Shape();shape.moveTo(-d/2,h+0.004);
  for(const v of curve)shape.lineTo(v.z,v.y);
  shape.lineTo(d/2,h+0.004);shape.closePath();
  const lid=new ExtrudeGeometry(shape,{depth:w,steps:1,bevelEnabled:false,curveSegments:1});
  lid.rotateY(Math.PI/2);lid.translate(-w/2,0,0);lid.clearGroups();
  mesh('lid','wood',lid);
  for(const sign of [-1,1]) {
    const x=sign*(w/2-w*Number(p.bandInset));
    for(const z of [-1,1])box('band-body-'+sign+'-'+z,'frame',[0.055,h-floor,0.012],[x,(h+floor)/2,z*(d/2+0.004)]);
    for(let i=0;i<6;i++) {
      const a=curve[i]!,b=curve[i+1]!;
      mesh('band-lid-'+sign+'-'+i,'frame',profiledBeam([x,a.y+0.007,-a.z],[x,b.y+0.007,-b.z],0.055,0.018,0.002));
    }
    box('hinge-'+sign,'frame',[0.08,0.09,0.025],[x,h,-d/2-0.012]);
  }
  if(p.latch) {
    box('latch','brass',[0.09,0.16,0.025],[0,h-0.03,d/2+0.015]);
    box('keyhole','frame',[0.014,0.028,0.008],[0,h-0.065,d/2+0.032]);
  }
  const pivotPoint:[number,number,number]=[0,h,-d/2];
  const pivot=jointGroup(root,'lid-pivot',pivotPoint,root.children.filter(item=>item.name==='lid'||item.name.startsWith('band-lid-')||item.name==='latch'||item.name==='keyhole'));
  pivot.rotation.x=-Number(p.lidAngle)*Math.PI/180;
  const joints=[{id:'lid-pivot',node:'lid-pivot',kind:'revolute' as const,pivot:pivotPoint,axis:[-1,0,0] as [number,number,number],angleUnit:'degrees' as const,limits:[0,110] as [number,number],angle:Number(p.lidAngle),parameter:'lidAngle'}];
  root.updateMatrixWorld(true);const bounds=new Box3().setFromObject(root,true);
  return {root,config,materials,anchors,joints,bounds,dimensions:bounds.getSize(new Vector3())};
}

const presets: Descriptor['presets'] = [
  {id:'oak',name:'Oak treasure chest',description:'Iron-bound oak chest with brass latch.',parameters:{}},
  {id:'small',name:'Open coffer',description:'Compact three-course coffer with its lid raised.',parameters:{width:0.7,depth:0.45,bodyHeight:0.35,lidRise:0.15,boardCount:3,lidAngle:85}},
  {id:'large',name:'Storage chest',description:'Broad six-course storage chest without a latch.',parameters:{width:1.8,depth:1,bodyHeight:0.8,lidRise:0.4,boardCount:6,latch:false}},
];
const boundaries: RecipeCase[] = controls.flatMap(c => c.kind === 'range' || c.kind === 'integer' ? [
  {id:c.key.toLowerCase()+'-min',name:c.label+' minimum',parameters:{[c.key]:c.min}},
  {id:c.key.toLowerCase()+'-max',name:c.label+' maximum',parameters:{[c.key]:c.max}},
] : []);
export const treasureChestRecipe: Recipe = {
  descriptor: {
    id:'treasure-chest',version:'1.0.0',title:'Wooden treasure chest',description:'A hollow oak chest with an opening faceted lid, iron bands and brass latch.',
    controls,defaults:parse({}),presets,
    palettes:Object.entries(palette).map(([id,colors]) => ({id,label:id === 'oak' ? 'Oak' : 'Painted',colors:Object.values(colors),parameters:Object.fromEntries(Object.entries(colors).map(([role,color])=>['color.'+role,color]))})),
    save,
    state(input) {return parameterState(controls,input);},
  },
  build,load,
  validationCases:[...presets,...boundaries,{id:'unlatched',name:'No latch',parameters:{latch:false}},{id:'small-open',name:'Small fully open coffer',parameters:{width:0.7,depth:0.45,bodyHeight:0.35,lidRise:0.4,boardCount:6,lidAngle:110}}],
  integrationCases:[{id:'default',name:'Default chest',parameters:{}},{id:'open',name:'Open coffer',parameters:presets[1]!.parameters}],
  constraints:['Static geometry in meters; lid opening is degrees, not animation. Body is hollow with a floor; lid is a closed solid with an underside. Bands and latch rotate around the rear hinge. Band inset is a fraction of width.'],
  presentation:{category:'Props',order:80,kitIds:[],thumbnails:Object.fromEntries(presets.map(p=>[p.id,'treasure-chest-'+p.id+'.png']))},
  source:{entry:'examples/recipes/treasure-chest/index.ts',exportName:'treasureChestRecipe'},
};
