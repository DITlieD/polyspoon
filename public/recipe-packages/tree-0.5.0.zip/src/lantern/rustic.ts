import {Box3,CylinderGeometry,Vector3} from 'three';
import {profileSolid,taperedSweep} from '../engine/geometry.ts';
import {Assembly} from '../families/assembly.ts';
import {colorways} from './config.ts';
import type {Configuration} from './config.ts';
export function rusticLantern(config:Configuration){
 const p=config.applied,w=p.bodyWidth,h=p.bodyHeight,d=w*.82,oct=p.enclosureProfile==='octagonal',cut=oct?w*.25:w*.035;
 const a=new Assembly(config,colorways[p.colorway]),rise=Number(p.hoodRise),base=w*.32,top=base+h,hoodY=top+w*.15*rise,capTop=top+w*.39*rise;
 const section=(name:string,role:string,rows:Array<[number,number,number]>)=>a.mesh(name,profileSolid(rows.map(([y,width,depth])=>({y,width,depth,chamfer:Math.min(cut,width*.28,depth*.28)}))),role);
 section('foot','structure',[[0,w*.82,d*.84],[w*.04,w*.94,d*.98],[w*.075,w*.94,d*.98]]);
 section('oil-reservoir','body',[[w*.065,w*.94,d*.98],[w*.12,w,d],[w*.25,w*.96,d*.96],[base,w*.78,d*.8]]);
 section('burner-collar','structure',[[base-w*.03,w*.4,d*.4],[base+w*.035,w*.34,d*.34]]);
 section('enclosure','enclosure',[[base,w*.70,d*.70],[base+h*.2,w*.88,d*.88],[base+h*.77,w*.79,d*.79],[top,w*.60,d*.60]]);
 section('lower-frame','structure',[[base-w*.022,w*.84,d*.84],[base+w*.025,w*.84,d*.84]]);
 section('upper-frame','structure',[[top-w*.025,w*.72,d*.72],[top+w*.025,w*.72,d*.72]]);
 const frame=w*(p.frameWeight==='heavy'?.034:.026);
 for(let i=0;i<Number(p.guardCount);i++){
  const t=(i+.5)*Math.PI*2/Number(p.guardCount),dx=Math.cos(t),dz=Math.sin(t);
  const radial=(width:number,depth:number)=>{
    const chamfer=Math.min(cut,width*.28,depth*.28);
    return Math.min(width*.5/Math.max(1e-8,Math.abs(dx)),depth*.5/Math.max(1e-8,Math.abs(dz)),(width*.5+depth*.5-chamfer)/(Math.abs(dx)+Math.abs(dz)))+frame*1.12;
  };
  const stations:Array<[number,number,number]>=[[base-w*.012,w*.84,d*.84],[base+h*.2,w*.88,d*.88],[base+h*.77,w*.79,d*.79],[top+w*.012,w*.72,d*.72]];
  a.mesh('guard-upright-'+i,taperedSweep(stations.map(([y,width,depth])=>{const r=radial(width,depth);return {center:[dx*r,y,dz*r] as [number,number,number],radius:frame};}),6),'structure');
 }
 if(p.guardLayout==='crossbar')for(const z of [-1,1])a.beam('guard-crossbar-'+z,[-w*.34,base+h*.48,z*d*.43],[w*.34,base+h*.48,z*d*.43],frame,frame,'structure');
 const flare=1+Number(p.hoodFlare)*1.5;
 section('hood','body',[[top,w*.72,d*.72],[top+w*.055,w*flare,d*flare],[top+w*.11*rise,w*flare,d*flare],[hoodY,w*.55,d*.55]]);
 section('vent-core','structure',[[hoodY-w*.015,w*.39,d*.39],[capTop-w*.055,w*.35,d*.35]]);
 for(let i=0;i<8;i++){
  const t=i*Math.PI/4,x=Math.cos(t)*w*.235,z=Math.sin(t)*d*.235;
  a.beam('vent-divider-'+i,[x,hoodY-w*.012,z],[x*.85,capTop-w*.05,z*.85],w*.033,w*.035,'body');
 }
 section('vented-cap','body',[[capTop-w*.07,w*.58,d*.58],[capTop-w*.03,w*.60,d*.60],[capTop+w*.085,w*.30,d*.30],[capTop+w*.11,w*.30,d*.30]]);
 const mountY=hoodY+w*.01,rx=w*(p.carryHoop==='round'?.39:p.carryHoop==='tall'?.28:.33);
 const wire=w*.022,gapBottom=capTop+w*.14,gapHeight=p.handleClearance,requestedHalf=rx*.55;
 const profile=Array.from({length:17},(_,i)=>{const t=-Math.PI/2+i*Math.PI*2/16;return {x:Math.cos(t),y:(1+Math.sin(t))/2};});
 const crossing=(x:number)=>{
  const ys:number[]=[];
  for(let i=0;i<profile.length-1;i++){
   const a=profile[i]!,b=profile[i+1]!;
   if(Math.abs(b.x-a.x)<1e-9||x<Math.min(a.x,b.x)-1e-9||x>Math.max(a.x,b.x)+1e-9)continue;
   ys.push(a.y+(b.y-a.y)*(x-a.x)/(b.x-a.x));
  }
  return Math.max(...ys);
 };
 const cornerFraction=crossing((requestedHalf+wire*1.5)/rx);
 const hoopTop=mountY+(gapBottom+gapHeight+wire*1.5-mountY)/cornerFraction;
 const cy=(mountY+hoopTop)/2,ry=(hoopTop-mountY)/2;
 const innerHalfAt=(y:number)=>{
  const level=(y-mountY)/(hoopTop-mountY),xs:number[]=[];
  for(let i=0;i<profile.length-1;i++){
   const a=profile[i]!,b=profile[i+1]!;
   if(Math.abs(b.y-a.y)<1e-9||level<Math.min(a.y,b.y)-1e-9||level>Math.max(a.y,b.y)+1e-9)continue;
   const x=a.x+(b.x-a.x)*(level-a.y)/(b.y-a.y);if(x>=0)xs.push(x*rx);
  }
  return Math.min(...xs)-wire*1.5;
 };
 const gapWidth=2*Math.min(innerHalfAt(gapBottom),innerHalfAt(gapBottom+gapHeight));
 if(!Number.isFinite(gapWidth)||gapWidth<requestedHalf*2)throw new Error('Hoop profile cannot retain requested carry opening');
 const points:Array<{center:[number,number,number];radius:number}>=[];
 for(let i=0;i<=16;i++){
  const t=-Math.PI/2+i*Math.PI*2/16;
  points.push({center:[Math.cos(t)*rx,cy+Math.sin(t)*ry,0],radius:wire});
 }
 a.mesh('handle',taperedSweep(points,6),'structure');
 for(const side of [-1,1]){
  a.beam('handle-seat-'+side,[side*w*.23,hoodY-w*.025,0],[side*rx*.75,cy-ry*.68,0],w*.065,w*.09,'body');
  if(p.detail==='inspection'){
   const pin=a.mesh('handle-rivet-'+side,new CylinderGeometry(w*.019,w*.019,w*.03,8),'accent',[side*w*.25,hoodY+w*.015,w*.065]);pin.rotation.x=Math.PI/2;
  }
 }
 const root=a.root;root.updateMatrixWorld(true);const bounds=new Box3().setFromObject(root,true);
 const anchors={ground:[0,0,0],carry:[0,hoopTop+wire,0]};root.userData.anchors=anchors;
 return {root,config,materials:a.materials,bounds,dimensions:bounds.getSize(new Vector3()),handleGap:{width:gapWidth,bottom:gapBottom,height:gapHeight},anchors};
}
