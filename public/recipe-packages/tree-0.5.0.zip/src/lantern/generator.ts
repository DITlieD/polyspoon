import {Box3,CylinderGeometry,Mesh,Vector3} from 'three';
import {rusticLantern} from './rustic.ts';
import {colorways,saveConfiguration} from './config.ts';
import {carryingBand,profileSolid,taperedSweep} from '../engine/geometry.ts';
import {Assembly} from '../families/assembly.ts';
export function generateLantern(input:unknown){
 const config=saveConfiguration(input);if(config.applied.construction==='rustic')return rusticLantern(config);
 const p=config.applied,w=p.bodyWidth,h=p.bodyHeight,d=w*.76,baseTop=w*.20,hoodBottom=baseTop+h,crownTop=hoodBottom+w*.38;
 const assembly=new Assembly(config,colorways[p.colorway]),root=assembly.root,materials=assembly.materials;
 const add=assembly.mesh.bind(assembly),heavy=p.frameWeight==='heavy',octagonal=p.enclosureProfile==='octagonal',frame=w*(heavy?.055:.039),flare=Number(p.hoodFlare);
 add('foot',profileSolid([{y:0,width:w*.95,depth:d*.98,chamfer:w*.10},{y:w*.055,width:w*1.1,depth:d*1.12,chamfer:w*.10}]),'structure');
 add('base',profileSolid([{y:w*.04,width:w*1.1,depth:d*1.12,chamfer:w*.10},{y:w*.10,width:w*1.16,depth:d*1.18,chamfer:w*.11},{y:baseTop,width:w*.92,depth:d*.94,chamfer:w*.08}]),'body');
 const chamfer=octagonal?w*.23:w*.06;
 add('enclosure',profileSolid([{y:baseTop,width:w*.85,depth:d*.88,chamfer:chamfer*.83},{y:baseTop+h*.22,width:w,depth:d,chamfer},{y:hoodBottom-h*.13,width:w*.93,depth:d*.94,chamfer:chamfer*.91},{y:hoodBottom,width:w*.81,depth:d*.84,chamfer:chamfer*.78}]),'enclosure');
 for(const [name,y,width,depth] of [['lower-frame',baseTop,w*.93,d*.98],['upper-frame',hoodBottom-w*.025,w*.91,d*.98]] as const){
  add(name,profileSolid([{y,width,depth,chamfer:octagonal?w*.18:w*.05},{y:y+w*.045,width,depth,chamfer:octagonal?w*.18:w*.05}]),'body');
 }
 const support=(angle:number)=>{
  const x=Math.cos(angle),z=Math.sin(angle),cut=octagonal?w*.19:w*.045;
  const r=Math.min(w*.51/Math.max(1e-8,Math.abs(x)),d*.52/Math.max(1e-8,Math.abs(z)),(w*.51+d*.52-cut)/(Math.abs(x)+Math.abs(z)));
  return [x*r,z*r] as const;
 };
 for(let i=0;i<Number(p.guardCount);i++){
  const angle=(i+.5)*Math.PI*2/Number(p.guardCount),[x,z]=support(angle);
  add('guard-upright-'+i,taperedSweep([{center:[x*.88,baseTop+w*.016,z*.88],radius:frame*.49},{center:[x,baseTop+h*.23,z],radius:frame*.40},{center:[x*.87,hoodBottom+w*.012,z*.87],radius:frame*.36}],7),'structure');
 }
 if(p.guardLayout==='crossbar')for(const side of [-1,1])assembly.beam('guard-crossbar-'+side,[-w*.40,baseTop+h*.44,side*d*.50],[w*.40,baseTop+h*.55,side*d*.50],frame*.60,frame*.44,'structure',w*.005);
 add('vent-core',profileSolid([{y:hoodBottom,width:w*.63,depth:d*.64,chamfer:w*.07},{y:hoodBottom+w*.14,width:w*.59,depth:d*.6,chamfer:w*.065}]),'structure');
 for(const side of [-1,1])for(let i=0;i<5;i++){
  assembly.beam('vent-divider-'+side+'-'+i,[(i-2)*w*.105,hoodBottom,side*d*.335],[(i-2)*w*.105,hoodBottom+w*.14,side*d*.31],w*.029,w*.035,'body',w*.004);
 }
 add('hood',profileSolid([{y:hoodBottom+w*.11,width:w*(1+2*flare),depth:d*(1+2*flare),chamfer:w*.14},{y:hoodBottom+w*.155,width:w*(1+2*flare),depth:d*(1+2*flare),chamfer:w*.14},{y:crownTop-w*.045,width:w*.52,depth:d*.56,chamfer:w*.06},{y:crownTop,width:w*.52,depth:d*.56,chamfer:w*.06}]),'body');
 const band=w*.052,handleBase=crownTop+w*.09;
 if(p.handleProfile==='square')add('handle',carryingBand(w*.62,handleBase-w*.025,handleBase+p.handleClearance,band,w*.095),'structure');
 else{
  const x=w*.34,top=handleBase+p.handleClearance+band,corner=Math.min(w*.13,p.handleClearance*.44),points:Array<[number,number,number]>=[[-x,handleBase-w*.025,0],[-x,top-corner,0]];
  for(let i=1;i<=5;i++){const t=i*Math.PI/10;points.push([-x+corner-corner*Math.cos(t),top-corner+corner*Math.sin(t),0]);}
  points.push([x-corner,top,0]);
  for(let i=1;i<=5;i++){const t=i*Math.PI/10;points.push([x-corner+corner*Math.sin(t),top-corner+corner*Math.cos(t),0]);}
  points.push([x,handleBase-w*.025,0]);
  add('handle',taperedSweep(points.map(center=>({center,radius:band})),8),'structure');
 }
 const seatX=w*(p.handleProfile==='square'?.38:.34);
 for(const side of [-1,1]){
  add('handle-seat-'+side,profileSolid([{y:crownTop-w*.075,width:w*.12,depth:w*.17,chamfer:w*.015},{y:handleBase+w*.02,width:w*.11,depth:w*.15,chamfer:w*.015}]),'body',[side*seatX,0,0]);
  if(p.detail==='inspection'){const pin=add('handle-rivet-'+side,new CylinderGeometry(w*.02,w*.02,w*.02,8),'accent',[side*seatX,handleBase-w*.02,w*.085]);pin.rotation.x=Math.PI/2;}
 }
 const plateDepth=w*.025,buttonDepth=w*.025,plateZ=d*.57;
 assembly.box('switch-plate',[w*.18,w*.10,plateDepth],'structure',[0,w*.115,plateZ]);
 const button=add('switch',new CylinderGeometry(w*.034,w*.034,buttonDepth,8),'accent',[0,w*.115,plateZ+plateDepth/2+buttonDepth/2]);button.rotation.x=Math.PI/2;
 root.updateMatrixWorld(true);const bounds=new Box3().setFromObject(root,true);
 const handleGap={width:w*(p.handleProfile==='arched'?.32:.62),bottom:handleBase,height:p.handleClearance};
 const anchors={ground:[0,0,0],carry:[0,handleBase+p.handleClearance+band,0]};root.userData.anchors=anchors;
 return {root,config,materials,bounds,dimensions:bounds.getSize(new Vector3()),handleGap,anchors};
}
export type LanternBuild=ReturnType<typeof generateLantern>;
export function disposeLantern(build:LanternBuild){build.root.traverse(o=>{if(o instanceof Mesh)o.geometry.dispose();});for(const m of Object.values(build.materials))m.dispose();}
