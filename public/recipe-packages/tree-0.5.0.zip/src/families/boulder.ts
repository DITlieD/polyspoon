import {Vector3,BufferGeometry,Float32BufferAttribute,Vector2,ShapeUtils} from 'three';
import {clippedStoneFaces} from '../engine/convex-stone.ts';
import {Assembly} from './assembly.ts';
import {palettes} from './config.ts';
import type {Configuration} from './config.ts';
export function boulder(config:Configuration){
 const p=config.applied,a=new Assembly(config,{...palettes[p.colorway],moss:'#66724b'}),w=Number(p.width),h=Number(p.height),d=Number(p.depth),lean=Number(p.lean);
 const angularity=Number(p.angularity),crest=Number(p.crest),shoulder=Number(p.shoulderHeight),standing=p.form==='standing';
 let seed=(Number(p.seed)+1)>>>0;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const bias=(random()-.5)*.045,cut=.06+(1-angularity)*.16;
 const traditionalCuts=[
  {normal:[1,standing?.24:.43,.35],limit:.53+bias},
  {normal:[-1,.16,.18],limit:.48-bias},
  {normal:[-.32,.28,1],limit:.55},
  {normal:[.26,.37,-1],limit:.47},
  {normal:[1,-.38,.23],limit:.43},
  {normal:[-1,-.53,.04],limit:.40},
  {normal:[-.13,-.42,1],limit:.47},
  {normal:[.24,-.34,-1],limit:.37},
  {normal:[1,.17,.72],limit:.81-cut*.8},
  {normal:[-.55,.18,1],limit:.78-cut*.9},
  {normal:[.65,.16,-1],limit:.78-cut*.55},
  {normal:[-1,.31,-.64],limit:.78-cut*.85},
  {normal:[.85,1.18,.32],limit:.33+shoulder*1.18},
  {normal:[-1,.78,.20],limit:.35+shoulder*.98},
  {normal:[-.23,1.12,1],limit:.30+shoulder*1.12},
  {normal:[.28,.94,-1],limit:.48+shoulder*1.10},
  {normal:[-(crest*.40+.18),1,.14],limit:.90},
 ];
 const field=p.form==='field',grade=Number(p.facetGrade),burial=Number(p.burialDepth);
 const fieldCuts:Array<{normal:[number,number,number];limit:number}>=[];
 const sides=grade===0?7:grade===1?9:12;
 for(let i=0;i<sides;i++){
  const angle=i*Math.PI*2/sides+.13+.10*Math.sin(i*1.8),dx=Math.cos(angle),dz=Math.sin(angle),r=.51+(random()-.5)*(.06+angularity*.08);
  fieldCuts.push({normal:[dx,.23+.16*Math.sin(i*1.7+.4),dz],limit:r+.10+.035*Math.sin(i*2.3)});
  fieldCuts.push({normal:[dx,.57+.21*Math.sin(i*2.1+.7),dz],limit:r+.27+shoulder*.13+.09*Math.sin(i*1.3)});
  fieldCuts.push({normal:[dx,-.47-.22*Math.cos(i*1.9),dz],limit:r-.065+.025*Math.sin(i)});
 }
 fieldCuts.push({normal:[-.07-crest*.2,1,.055],limit:1.01});
 const cuts=field?fieldCuts:traditionalCuts as Array<{normal:[number,number,number];limit:number}>;
 cuts.push({normal:[0,-1,0],limit:-burial*.6});
 const normalized=clippedStoneFaces(cuts);
 const all=normalized.flat(),topY=Math.max(...all.map(v=>v.y)),bottomY=Math.min(...all.map(v=>v.y));
 const faces=normalized.map(face=>face.map(v=>{
  const y=(v.y-bottomY)/(topY-bottomY);
  return new Vector3((v.x+lean*y+crest*y*.18)*w,y*h*(1-burial),v.z*d);
 }));
 const records=faces.map((vertices,index)=>{
  const normal=vertices[1]!.clone().sub(vertices[0]!).cross(vertices[2]!.clone().sub(vertices[0]!)).normalize();
  const center=vertices.reduce((s,v)=>s.add(v),new Vector3()).multiplyScalar(1/vertices.length);
  let area=0;for(let i=1;i<vertices.length-1;i++)area+=vertices[i]!.clone().sub(vertices[0]!).cross(vertices[i+1]!.clone().sub(vertices[0]!)).length()/2;
  return {vertices,index,normal,center,area};
 });
 const facing=(f:typeof records[number])=>f.area*(.4+Math.max(0,f.normal.z)+Math.max(0,f.normal.x)*.5);
 const eligible=records.filter(f=>f.vertices.length>=4&&f.normal.y>.3&&f.center.y>h*(1-burial)*.42).sort((a,b)=>facing(b)-facing(a));
 const mossFaces=new Set(p.moss==='top'?eligible.slice(0,field?Math.min(eligible.length,3+Math.floor(Number(p.mossCoverage)*3)):Number(p.mossCoverage)>.6?2:1).map(f=>f.index):[]);
 const stone:number[]=[],moss:number[]=[],patches:unknown[]=[];
 const tri=(out:number[],a:Vector3,b:Vector3,c:Vector3)=>out.push(...a.toArray(),...b.toArray(),...c.toArray());
 for(const face of records){
  const vertices=face.vertices;
  if(!mossFaces.has(face.index)){
   for(let i=1;i<vertices.length-1;i++)tri(stone,vertices[0]!,vertices[i]!,vertices[i+1]!);
   continue;
  }
  const forward=face.normal.dot(new Vector3(2.7,1.85,3.5).normalize())>.15;
  const scale=(.29+Number(p.mossCoverage)*.49)*(forward?1.06:1);
  const u=vertices[0]!.clone().sub(face.center).normalize(),v=face.normal.clone().cross(u);
  const project=(q:Vector3)=>{const delta=q.clone().sub(face.center);return new Vector2(delta.dot(u),delta.dot(v));};
  const outer=vertices.map(project),cross=(a:Vector2,b:Vector2)=>a.x*b.y-a.y*b.x;
  const patch=Array.from({length:6},(_,i)=>{
   const angle=i*Math.PI/3+face.index*.17,direction=new Vector2(Math.cos(angle),Math.sin(angle));
   let distance=Infinity;
   for(let j=0;j<outer.length;j++){
    const a=outer[j]!,edge=outer[(j+1)%outer.length]!.clone().sub(a),denominator=cross(direction,edge);
    if(Math.abs(denominator)<1e-10)continue;
    const t=cross(a,edge)/denominator,s=cross(a,direction)/denominator;
    if(t>0&&s>=-1e-8&&s<=1+1e-8)distance=Math.min(distance,t);
   }
   const radius=distance*scale*(.78+.16*Math.sin(i*1.7+face.index));
   return face.center.clone().addScaledVector(u,direction.x*radius).addScaledVector(v,direction.y*radius);
  });
  const all=[...vertices,...patch],inner=patch.map(project);
  for(const [i,j,k] of ShapeUtils.triangulateShape(outer,[inner])){
   const a=all[i!]!,b=all[j!]!,c=all[k!]!;
   if(b.clone().sub(a).cross(c.clone().sub(a)).dot(face.normal)>0)tri(stone,a,b,c);else tri(stone,a,c,b);
  }
  for(let i=1;i<patch.length-1;i++)tri(moss,patch[0]!,patch[i]!,patch[i+1]!);
  patches.push({face:face.index,outer:vertices.map(v=>v.toArray()),vertices:patch.map(v=>v.toArray())});
 }
 for(const [name,role,positions] of [['stone-mass','stone',stone],['moss-region','moss',moss]] as const){
  if(!positions.length)continue;
  const geometry=new BufferGeometry();geometry.setAttribute('position',new Float32BufferAttribute(positions,3));geometry.computeVertexNormals();
  const mesh=a.mesh(name,geometry,role);
  if(role==='stone')mesh.userData.majorFaces=faces.map(vertices=>({vertices:vertices.map(v=>v.toArray())}));
  else mesh.userData.patches=patches;
 }
 a.anchors.top=faces.flat().reduce((best,v)=>v.y>best.y?v:best,faces[0]![0]!).toArray() as [number,number,number];
 return a.finish();
}
