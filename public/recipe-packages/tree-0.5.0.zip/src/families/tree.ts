import { taperedSweep } from '../engine/geometry.ts';
import { Vector3 } from 'three';
import { ConvexGeometry } from 'three/addons/geometries/ConvexGeometry.js';
import { Assembly } from './assembly.ts';
import type { Configuration, Role } from './config.ts';

function crownGeometry(size: [number, number, number], random: () => number,round=false) {
  const shoulders = Array.from({ length: 8 }, () => 0.8 + random() * 0.35);
  const angles = shoulders.map((_, i) => i * Math.PI / 4 + (random() - 0.5) * 0.16);
  const profilePhase = random() * Math.PI * 2;
  const points = [new Vector3(round?-.035:-0.12, -0.5, round?.02:0.06), new Vector3(round?.035:0.12 + random() * 0.18, 0.52, round?-.02:-0.12)];
  for (const [y, radius, offsetX, offsetZ] of [
    [-0.30, 0.70, -0.10, 0.06],
    [0.04, 1.00, 0, 0],
    [0.33, 0.68, 0.16, -0.09],
  ]) {
    for (let i = 0; i < 8; i++) {
      const r = radius! * shoulders[i]! * (0.94 + random() * 0.12), angle = angles[i]!;
      const profile = (round?.035:.17) * Math.sin(angle + profilePhase) + (round?.025:.075) * Math.sin(2 * angle - profilePhase);
      const height = y! + profile * (radius! > 0.9 ? 1 : 0.45) + (random() - 0.5) * 0.025;
      points.push(new Vector3(Math.cos(angle) * r + offsetX!*(round?.25:1), height, Math.sin(angle) * r + offsetZ!*(round?.25:1)));
    }
  }
  const geometry = new ConvexGeometry(points);
  geometry.rotateY(random() * Math.PI * 2);
  geometry.computeBoundingBox();
  const bounds = geometry.boundingBox!, extent = bounds.getSize(new Vector3()), center = bounds.getCenter(new Vector3());
  geometry.translate(-center.x, -center.y, -center.z);
  geometry.scale(size[0] / extent.x, size[1] / extent.y, size[2] / extent.z);
  geometry.computeVertexNormals();
  return geometry;
}


export function tree(config: Configuration) {
  const a=new Assembly(config),p=config.applied,h=Number(p.height),s=Number(p.spread),lean=Number(p.lean)*h;
  const mature=p.growth==='mature',upright=p.architecture==='upright',full=Number(p.canopyFullness);
  const girth=Number(p.trunkGirth)*(mature?1:.82),forkY=h*Number(p.forkHeight),count=Number(p.branchCount);
  const randomFor=(id:string)=>{
    let state=(Number(p.seed)+1)>>>0;
    for(const c of id)state=Math.imul(state^c.charCodeAt(0),16777619)>>>0;
    return ()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
  };
  const base:[number,number,number]=[0,0,0],fork:[number,number,number]=[lean*.35,forkY,0];
  const upper:[number,number,number]=[lean*.65+h*.025,h*.64,-s*.025];
  a.mesh('trunk',taperedSweep([
    {center:base,radius:girth*1.45},{center:[0,h*.045,0],radius:girth*1.18},
    {center:[-h*.018,h*.16,0],radius:girth*.96},{center:fork,radius:girth*.78},
    {center:[lean*.52+h*.035,(forkY+h*.64)/2,s*.025],radius:girth*.59},{center:upper,radius:girth*.30},
  ],9),'timber');
  for(let i=0;i<5;i++){
    const angle=i*Math.PI*2/5+.3,dx=Math.cos(angle),dz=Math.sin(angle),r=girth*(2.5+randomFor('root'+i)()*.45),side=girth*.45;
    const points=[[dx*r,0,dz*r],[dx*girth-side*dz,0,dz*girth+side*dx],[dx*girth+side*dz,0,dz*girth-side*dx],
      [dx*girth*.65,h*.11,dz*girth*.65],[dx*r*.78,girth*.17,dz*r*.78]].map(q=>new Vector3(...q as [number,number,number]));
    a.mesh('root-'+i,new ConvexGeometry(points),'timber');
  }
  for(let i=0;i<count;i++){
    const random=randomFor('architecture-'+i),angle=(i===1?.65:i===2?2.95:i*2.399963)+(random()-.5)*.18;
    const major=i===0,radial=major?0:s*(upright?.24:.34)*(i%2?.92:1.08);
    const crownHeight=h*(major?.56:(.30+(i%3)*.035))*full*(mature?1:.91);
    const cy=major?h-crownHeight/2:h*(.48+(i%3)*.065)+(upright?.035*h:0);
    const center:[number,number,number]=[lean+Math.cos(angle)*radial,cy,Math.sin(angle)*radial*.85];
    const width=s*(major?.71:.35+(i%3)*.045)*full*(upright?.85:1);
    const size:[number,number,number]=[width,crownHeight,width*(major?.97:.85+(i%2)*.12)];
    const name=i===0?'main':String(i),role:Role=major?'foliage':i%2?'foliageShade':'foliageLight';
    a.mesh('crown-'+name,crownGeometry(size,randomFor('crown-'+name),major),role,center);
    const start:[number,number,number]=i===0?upper:[fork[0],fork[1]+(i%3)*h*.04,0];
    const middle:[number,number,number]=[start[0]+(center[0]-start[0])*.62,Math.min(cy-h*.09,start[1]+(cy-start[1])*.48),center[2]*.5];
    const branch=a.mesh('branch-'+name,taperedSweep([{center:start,radius:girth*(major?.34:.49)},{center:middle,radius:girth*.31},{center:center,radius:girth*.10}],8),'timber');
    branch.userData.tip=[...center];
  }
  a.anchors.fork=[...fork];a.anchors.crown=[lean,h,0];return a.finish();
}
