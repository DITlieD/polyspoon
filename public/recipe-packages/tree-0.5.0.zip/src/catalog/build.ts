import { attachSemantics } from './semantics.ts';
import { Mesh } from 'three';
import { splitAppearance, styleAsset } from './appearance.ts';
import type { Recipe } from '../recipes/types.ts';
import type { SemanticAssetBuild, Preview } from './types.ts';

export function buildRecipeAsset(recipe:Recipe,input:unknown={}):SemanticAssetBuild {
  const {parameters,appearance}=splitAppearance(input);
  const build=recipe.build(parameters);
  try{styleAsset(build,appearance);attachSemantics(build,recipe.descriptor.controls);return build as SemanticAssetBuild;}catch(error){disposeAsset(build);throw error;}
}
export function disposeAsset(build:Preview):void {
  build.root.traverse(object=>{if(object instanceof Mesh)object.geometry.dispose();});
  for(const material of new Set(Object.values(build.materials)))material.dispose();
}
